from flask import Flask,request,jsonify
import pickle
import numpy as np
import json

model=pickle.load(open('age_thyroid.pkl','rb'))
diab=Flask(__name__)


@diab.route('/predict_age_thyroid',methods=['POST'])
def predict():
    data = request.json['data']
    # convert the array to a numpy array
    arr = np.array(data).reshape(1, -1)
    num = model.predict(arr)[0]
    result = {'result': int(num)}
    # return the result as a JSON object
    return jsonify(result)

if __name__=='__main__':
    diab.run(debug=True)
